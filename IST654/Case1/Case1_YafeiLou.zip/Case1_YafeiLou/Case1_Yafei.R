#load the data
CAPM = read.csv("./Downloads/Case1CAPM.csv")

#dimension and names of the variables
dim(CAPM)
names(CAPM)

View(CAPM)

DATE = as.Date(as.character(CAPM$DATE),"%Y%m%d")

ibmRET = CAPM$IBMRET
RF = CAPM$RF
#excess returns of IBM
IBMEXERT = ibmRET-RF

jpeg(filename="Case_IBMEXERT.jpeg")
plot(DATE,IBMEXERT,type="l",xlab="year",ylab="daily excess return(%)",main="IBM Excess Return(%)",ylim=c(-15,15))
dev.off()
#compute the arithmetic mean of IBM excess return
IBMMean = mean(IBMEXERT)*252
IBMMean
#compute the standard deviation of IBM return
IBMSTD = sd(IBMEXERT)*sqrt(252)
IBMSTD
#compute the sharp ratio of IBM excess return
IBMSR = IBMMean / IBMSTD
#compute the 5% value at risk of IBM excess return
IBMVaR = quantile(IBMEXERT,probs=c(0.05))
IBMVaR

#create a table to compare all the statistics 
comparison = data.frame(IBMMean,IBMSTD,IBMSR,IBMVaR)
View(comparison)

install.packages("PerformanceAnalytics")
install.packages("xts")
install.packages("zoo")
install.packages("e1071")
install.packages("tseries")
install.packages("nortest")
library(tseries)
library(xts)
library(zoo)
library(PerformanceAnalytics)
library(e1071)
library(nortest)
IBMEXERT_raw = IBMEXERT/100
IBMS_raw = ES(IBMEXERT_raw,p=.05,method="historical")
IBMES = IBMS_raw*100


#Boxplot of IBM excess return
boxplot(IBMEXERT,main="Boxplot of IBM excess return",ylab="daily excess return(%)")
#histogram of IBM excess return
hist(IBMEXERT,main="Daily IBM Excess returns(percentage)",prob=TRUE,xlab="IBM Excess Return",ylab="Density",ylim=c(0,0.25),breaks=50)

IBMskew = skewness(IBMEXERT)
IBMskew
IBMkurto = kurtosis(IBMEXERT)
IBMkurto 
#the results tell that p value less than 0.05 so we reject the numm hypothese
#in this case it does not follow a normal distribution
jarque.bera.test(IBMEXERT)
#same her the data is nor normally distrbuted
lillie.test(IBMEXERT)

 as.numeric(CAPM$MarketEXERT)
temp = CAPM$MarketEXRET
marketEXERT = CAPM$MarketEXRET
MKTskew<-skewness(marketEXERT)

MKTkurto<-kurtosis(marketEXERT)
MKTsd<-sd(marketEXERT)*sqrt(252)

MKTsr<-MKTmean/MKTsd
Name<-c("Mean:", "Std:", "Skewness:", "Kurtosis:","Sharpe Ratio","Value at Risk","Expected Shortfall","Correlation:" )

IBM<-c(IBMMean, IBMSTD, IBMskew, IBMkurto, IBMsr, IBMVaR, IBMES, IBMcMarket)

Market<-c(MKTmean, MKTsd, MKTskew, MKTkurto, MKTsr,MKTVaR, MKTES, NA)

MKTmean<-mean(temp)*252
MKTmean

MKTsd<-sd(marketEXERT)*sqrt(252)

MKTsr<-MKTmean/MKTsd
MKTVaR = quantile(temp, probs = c(0.05))
MKT_raw<- temp/100

MKTES_raw<-ES(MKT_raw, p=.05,method="historical")

MKTES<-MKTES_raw*100